#include <Arduino.h>
#include <ESP32Servo.h>

int value = 0; // initialize the variables you need
int escPin = 13;
int throttleValue =0; 
const int hallPin = 12;
volatile int pulseCount = 0;
unsigned long lastTime = 0;
unsigned int rpm = 0;
unsigned long interval = 1000;

Servo esc;

void IRAM_ATTR countPulse(){
  pulseCount++;
}

void setup() {
  Serial.begin(115200);   // start serial at 9600 baud
  //Setup the ESC
  esc.attach(escPin, 1000, 2000);   // attached to pin 9
  esc.writeMicroseconds(1500);  // Set the throttle to minimum to arm the ESC
  delay(7000);  // Wait for 3 seconds to allow the ESC to arm
  
  //Setup the hall sensor 
  pinMode(hallPin, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(hallPin), countPulse, FALLING);
  
}

void loop() {

  int signal = 1700; 

  esc.writeMicroseconds(signal); // Approximately 10% duty cycle @ 1KHz
  unsigned long currentTime = millis();

  // Calculate RPM every 1 second
  if (currentTime - lastTime >= interval) {
    // Disable interrupts while calculating RPM
    detachInterrupt(digitalPinToInterrupt(hallPin));

    // Calculate RPM based on the number of pulses
    rpm = (pulseCount * 60) / 1;  // 60 seconds per minute

    // Reset pulse counter and time
    pulseCount = 0;
    lastTime = currentTime;

    // Print the calculated RPM
    Serial.print("RPM: ");
    Serial.println(rpm);

    // Re-enable interrupts
    attachInterrupt(digitalPinToInterrupt(hallPin), countPulse, FALLING);
  }
}

